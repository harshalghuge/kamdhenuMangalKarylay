import { motion } from "framer-motion";
import {
  ArrowRight,
  CalendarDays,
  MapPin,
  Users,
  Utensils,
  Car,
  Snowflake,
  Sparkles,
} from "lucide-react";

import { business } from "../config/business";

const events = [
  {
    icon: "💍",
    en: "Wedding",
    mr: "लग्न समारंभ",
  },
  {
    icon: "🌸",
    en: "Engagement",
    mr: "साखरपुडा",
  },
  {
    icon: "🎉",
    en: "Reception",
    mr: "रिसेप्शन",
  },
  {
    icon: "🎂",
    en: "Birthday",
    mr: "वाढदिवस",
  },
];

const facilities = [
  {
    icon: Users,
    en: "Spacious Hall",
    mr: "प्रशस्त हॉल",
  },
  {
    icon: Snowflake,
    en: "AC Facility",
    mr: "एसी सुविधा",
  },
  {
    icon: Utensils,
    en: "Dining Facility",
    mr: "जेवणाची व्यवस्था",
  },
  {
    icon: Car,
    en: "Parking",
    mr: "पार्किंग सुविधा",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 25 },
  visible: { opacity: 1, y: 0 },
};

export default function Home({ language }) {
  const isMarathi = language === "mr";

  return (
    <main className="bg-[#faf7f0] overflow-hidden">

      {/* HERO SECTION */}

      <section
        id="home"
        className="relative min-h-[720px] h-[92svh] max-h-[950px] flex items-center"
      >

        <img
          src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=1920&q=85"
          alt="Wedding banquet hall decoration"
          fetchPriority="high"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />

        <div className="absolute inset-0 bg-gradient-to-r from-[#1c1311]/85 via-[#1c1311]/55 to-[#1c1311]/20" />

        <div className="relative z-10 max-w-[1400px] mx-auto w-full px-6 md:px-12 pt-24 pb-20">

          <motion.div
            initial="hidden"
            animate="visible"
            variants={{
              visible: {
                transition: {
                  staggerChildren: 0.15,
                },
              },
            }}
            className="max-w-3xl"
          >

            <motion.div variants={fadeUp}>
              <span className="inline-flex items-center gap-2 text-[#e9c995] text-[10px] md:text-xs tracking-[2px] uppercase font-semibold border border-[#e9c995]/40 px-4 py-2 rounded-full">
                <Sparkles size={14} />
                {isMarathi
                  ? "तुमच्या आनंदाच्या क्षणांसाठी"
                  : "A PLACE FOR YOUR SPECIAL MOMENTS"}
              </span>
            </motion.div>

            <motion.h1
              variants={fadeUp}
              className="font-marathi md:font-display text-white text-[46px] sm:text-6xl md:text-7xl lg:text-[82px] leading-[1.3] md:leading-[1.2] mt-8 font-medium"
            >
              {isMarathi ? (
                <>
                  तुमचा खास दिवस,
                  <br />
                  <span className="text-[#e8c18d]">
                    आमची जबाबदारी.
                  </span>
                </>
              ) : (
                <>
                  Celebrate Your
                  <br />
                  <span className="text-[#e8c18d]">
                    Special Moments.
                  </span>
                </>
              )}
            </motion.h1>

            <motion.p
              variants={fadeUp}
              className="font-marathi text-white/85 text-sm md:text-lg leading-8 mt-6 max-w-xl"
            >
              {isMarathi
                ? "लग्न, साखरपुडा, रिसेप्शन आणि इतर प्रत्येक आनंदाच्या सोहळ्यासाठी योग्य ठिकाण."
                : "A beautiful venue for weddings, engagements, receptions and every celebration that matters."}
            </motion.p>

            <motion.div
              variants={fadeUp}
              className="flex flex-col sm:flex-row gap-3 mt-9"
            >

              <a
                href="/contact"
                className="inline-flex items-center justify-center gap-3 bg-[#873b35] hover:bg-[#642c29] text-white px-7 py-4 rounded-full font-semibold text-sm transition-all duration-300 hover:-translate-y-1"
              >
                <CalendarDays size={18} />
                {isMarathi ? "चौकशी करा" : "Enquire Now"}
                <ArrowRight size={17} />
              </a>

              <a
                href="/halls"
                className="inline-flex items-center justify-center gap-2 border border-white/70 text-white hover:bg-white hover:text-[#30221e] px-7 py-4 rounded-full font-semibold text-sm transition-all duration-300"
              >
                {isMarathi ? "हॉल पहा" : "Explore Our Halls"}
              </a>

            </motion.div>

            <motion.div
              variants={fadeUp}
              className="flex items-center gap-2 mt-12 text-white/75 text-xs md:text-sm"
            >
              <MapPin size={17} className="text-[#e8c18d]" />
              {business.address}
            </motion.div>

          </motion.div>
        </div>

        <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-[#faf7f0] to-transparent" />

      </section>


      {/* INTRODUCTION */}

      <section id="about" className="py-20 md:py-28 px-5 md:px-10">

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeUp}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto text-center"
        >

          <span className="text-[#a77942] text-xs font-semibold tracking-[3px] uppercase">
            {isMarathi ? "शुभम मंगल कार्यालय" : "WELCOME TO SHUBHAM"}
          </span>

          <h2 className="font-marathi md:font-display text-3xl md:text-5xl leading-tight text-[#30221e] mt-5">
            {isMarathi
              ? "प्रत्येक आनंदाच्या क्षणासाठी एक सुंदर ठिकाण"
              : "A Beautiful Place For Every Celebration"}
          </h2>

          <p className="font-marathi text-[#75665c] text-sm md:text-base leading-8 mt-6 max-w-2xl mx-auto">
            {isMarathi
              ? "तुमच्या आयुष्यातील खास क्षण अधिक सुंदर बनवण्यासाठी शुभम मंगल कार्यालयात आपले स्वागत आहे. लग्न समारंभापासून ते विविध कार्यक्रमांपर्यंत, तुमच्या गरजेनुसार योग्य जागा आणि सुविधा."
              : "Welcome to Shubham Mangal Karyalay, a venue for your memorable occasions. From weddings to family celebrations, discover a welcoming space for your special events."}
          </p>

          <div className="w-20 h-[2px] bg-[#b9915b] mx-auto mt-8" />

        </motion.div>

      </section>


      {/* EVENTS */}

      <section className="bg-[#f0e9dd] py-20 px-5 md:px-10">

        <div className="max-w-[1200px] mx-auto">

          <div className="text-center mb-12">
            <span className="text-[#a77942] text-xs tracking-[3px] font-semibold">
              {isMarathi ? "आमचे कार्यक्रम" : "CELEBRATE WITH US"}
            </span>

            <h2 className="font-marathi md:font-display text-3xl md:text-5xl mt-4 text-[#30221e]">
              {isMarathi ? "प्रत्येक सोहळ्यासाठी" : "Events We Host"}
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">

            {events.map((event, index) => (
              <motion.div
                key={event.en}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className="bg-[#faf7f0] rounded-2xl p-6 md:p-9 text-center border border-[#e7ddcf] hover:-translate-y-1 transition-transform duration-300"
              >
                <span className="text-4xl md:text-5xl">
                  {event.icon}
                </span>

                <h3 className="font-marathi text-base md:text-lg font-semibold mt-5 text-[#30221e]">
                  {isMarathi ? event.mr : event.en}
                </h3>
              </motion.div>
            ))}

          </div>

        </div>

      </section>


      {/* FACILITIES */}

      <section className="py-20 md:py-28 px-5 md:px-10">

        <div className="max-w-[1200px] mx-auto">

          <div className="text-center mb-12">
            <span className="text-[#a77942] text-xs tracking-[3px] font-semibold">
              {isMarathi ? "आमच्या सुविधा" : "WHAT WE OFFER"}
            </span>

            <h2 className="font-marathi md:font-display text-3xl md:text-5xl mt-4">
              {isMarathi ? "तुमच्या सोयीसाठी" : "Facilities & Amenities"}
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-5">

            {facilities.map((item) => {
              const Icon = item.icon;

              return (
                <div
                  key={item.en}
                  className="border border-[#e7ddcf] rounded-2xl p-6 text-center hover:border-[#b9915b] transition-colors"
                >
                  <div className="w-14 h-14 mx-auto rounded-full bg-[#f0e9dd] flex items-center justify-center">
                    <Icon size={25} className="text-[#873b35]" />
                  </div>

                  <h3 className="font-marathi font-semibold text-sm md:text-base mt-4">
                    {isMarathi ? item.mr : item.en}
                  </h3>
                </div>
              );
            })}

          </div>

        </div>

      </section>


      {/* BOOKING CTA */}

      <section className="px-5 md:px-10 pb-24">

        <div className="max-w-[1200px] mx-auto bg-[#642c29] rounded-3xl p-8 md:p-16 text-center text-white">

          <span className="text-[#e8c18d] text-xs tracking-[3px]">
            {isMarathi ? "तुमचा खास दिवस जवळ आला आहे?" : "PLAN YOUR SPECIAL DAY"}
          </span>

          <h2 className="font-marathi md:font-display text-3xl md:text-5xl mt-5">
            {isMarathi
              ? "आजच चौकशी करा!"
              : "Let's Plan Your Celebration"}
          </h2>

          <p className="font-marathi text-white/75 mt-5 text-sm md:text-base">
            {isMarathi
              ? "हॉलची माहिती आणि उपलब्धतेसाठी आमच्याशी संपर्क साधा."
              : "Contact us to know more about our venue and availability."}
          </p>

          <a
            href={business.whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-[#faf7f0] text-[#642c29] px-7 py-4 rounded-full font-semibold mt-8 hover:bg-[#e8c18d] transition"
          >
            {isMarathi ? "WhatsApp वर चौकशी करा" : "Enquire on WhatsApp"}
            <ArrowRight size={18} />
          </a>

        </div>

      </section>

    </main>
  );
}