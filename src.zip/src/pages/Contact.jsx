export default function Contact() {
  return <div>Our Halls</div>;
}