import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  Phone,
  Flower2,
  ChevronRight,
} from "lucide-react";

import { business } from "../../config/business";

export default function Navbar({ language, setLanguage }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { label: language === "mr" ? "मुख्यपृष्ठ" : "Home", path: "/" },
    { label: language === "mr" ? "आमचे हॉल" : "Our Halls", path: "/halls" },
    { label: language === "mr" ? "गॅलरी" : "Gallery", path: "/gallery" },
    { label: language === "mr" ? "संपर्क" : "Contact", path: "/contact" },
  ];

  const changeLanguage = () => {
    setLanguage(language === "en" ? "mr" : "en");
  };

  return (
    <>
      <header className="fixed top-0 left-0 w-full z-50 bg-[#faf7f0]/95 backdrop-blur-md border-b border-[#e9dfd0]">

        <div className="max-w-[1400px] mx-auto px-5 md:px-10 h-[76px] flex items-center justify-between">

          {/* LOGO */}
          <Link to="/" className="flex items-center gap-2.5 shrink-0">
            <div className="w-10 h-10 rounded-full border border-[#b9915b] flex items-center justify-center">
              <Flower2 size={24} className="text-[#873b35]" />
            </div>

            <div>
              <h1 className="font-display text-xl md:text-2xl text-[#30221e] leading-tight">
                SHUBHAM
              </h1>

              <p className="text-[9px] tracking-[2.5px] text-[#873b35] font-semibold">
                MANGAL KARYALAY
              </p>
            </div>
          </Link>

          {/* DESKTOP NAVIGATION */}
          <nav className="hidden lg:flex items-center gap-9">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `text-sm font-medium transition-colors duration-200 ${
                    isActive
                      ? "text-[#873b35]"
                      : "text-[#554740] hover:text-[#873b35]"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          {/* DESKTOP ACTIONS */}
          <div className="hidden lg:flex items-center gap-5">

            <button
              onClick={changeLanguage}
              className="text-sm font-semibold text-[#873b35] border border-[#d9c5a9] px-3 py-2 rounded-full hover:bg-[#f1e8dc] transition"
            >
              {language === "en" ? "मराठी" : "English"}
            </button>

            <a
              href={business.callLink}
              className="flex items-center gap-2 bg-[#873b35] text-white px-5 py-3 rounded-full text-sm hover:bg-[#642c29] transition"
            >
              <Phone size={16} />
              {language === "mr" ? "कॉल करा" : "Call Now"}
            </a>

          </div>

          {/* MOBILE ACTIONS */}
          <div className="flex lg:hidden items-center gap-3">

            <button
              onClick={changeLanguage}
              className="text-xs font-semibold text-[#873b35] border border-[#d9c5a9] px-3 py-2 rounded-full"
            >
              {language === "en" ? "मराठी" : "EN"}
            </button>

            <button
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
              className="w-10 h-10 flex items-center justify-center text-[#30221e]"
            >
              {menuOpen ? <X size={25} /> : <Menu size={25} />}
            </button>

          </div>

        </div>
      </header>

      {/* MOBILE MENU */}
      <AnimatePresence>
        {menuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMenuOpen(false)}
              className="fixed inset-0 bg-black/40 z-40 lg:hidden"
            />

            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="fixed top-0 right-0 h-full w-[82%] max-w-[350px] bg-[#faf7f0] z-50 shadow-2xl p-6 pt-24 lg:hidden"
            >

              <p className="text-xs tracking-[3px] text-[#a77942] mb-7">
                EXPLORE SHUBHAM
              </p>

              <nav className="flex flex-col">

                {navItems.map((item, index) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => setMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center justify-between py-5 border-b border-[#e9dfd0] text-lg ${
                        isActive
                          ? "text-[#873b35] font-semibold"
                          : "text-[#30221e]"
                      }`
                    }
                  >
                    {item.label}
                    <ChevronRight size={18} />
                  </NavLink>
                ))}

              </nav>

              <div className="mt-10 flex flex-col gap-3">

                <a
                  href={business.callLink}
                  className="flex justify-center items-center gap-2 bg-[#873b35] text-white py-4 rounded-full"
                >
                  <Phone size={18} />
                  {language === "mr" ? "आता कॉल करा" : "Call Now"}
                </a>

                <p className="text-center text-xs text-[#897b70]">
                  {business.address}
                </p>

              </div>

            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}