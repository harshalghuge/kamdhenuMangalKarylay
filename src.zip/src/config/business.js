export const business = {
  name: "Kamdhenu Mangal Karyalay",
  shortName: "Kamdhenu",
  address: "Wadgaon Road, Alandi, Pune, Maharashtra",

  // Replace these with the actual business number.
  phone: "+91 7719070451",

  get callLink() {
    return `tel:+${this.phone}`;
  },

  get whatsappLink() {
    return `https://wa.me/${this.phone}`;
  },
};