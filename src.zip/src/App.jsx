import { useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";

import Navbar from "./components/layout/Navbar";
import MobileBottomBar from "./components/layout/MobileBottomBar";

import Home from "./pages/Home";

function Placeholder({ title }) {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="font-display text-3xl">{title}</h1>
    </div>
  );
}

function Website() {
  const [language, setLanguage] = useState("en");

  return (
    <>
      <Navbar
        language={language}
        setLanguage={setLanguage}
      />

      <Routes>
        <Route
          path="/"
          element={<Home language={language} />}
        />

        <Route
          path="/halls"
          element={<Placeholder title="Our Halls" />}
        />

        <Route
          path="/gallery"
          element={<Placeholder title="Gallery" />}
        />

        <Route
          path="/contact"
          element={<Placeholder title="Contact Us" />}
        />
      </Routes>

      <MobileBottomBar language={language} />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Website />
    </BrowserRouter>
  );
}